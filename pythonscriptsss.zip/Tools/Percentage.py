def get_per(amount):
    full = 100
    for time in range(amount):
        if full > 0.00019073486328125:
            full = full / 2
            print("Chance to win after", time+1, "tries:", full, "%")
        else:
            print("No point going further. Python would crash xd")
            break


def main():
    chances = input("Enter the number of times you want to gamble: ")
    if chances.isdigit():
        chances = int(chances)
        get_per(chances)
    else:
        main()


main()
