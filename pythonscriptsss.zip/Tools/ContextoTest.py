import requests
import urllib3
import os

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

file = open("./text/wordlist.txt", "r")
user_agent = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0'}

load = "❌❌❌❌❌❌❌❌❌❌----------"
percentage = 0
retrieve1 = 9
retrieve2 = 19

error1 = str("This word")
error2 = str("I don't know this word")
system = str("title " + "Progress bar: " + load[10:20])

os.system("cls")
score = input("Enter the max score a word can have: ")
print("\n")

for entry in file:
    percentage += 1

    if percentage % 300 == 0:
        bar = load[retrieve1:retrieve2]
        retrieve1 -= 1
        retrieve2 -= 1
        system = str("title " + "Progress bar: " + bar)

    os.system(system)

    num = ''
    left = ":"
    right = ","

    urls = "https://api.contexto.me/machado/en/game/132/" + entry
    url = urls[:-1]

    response = requests.get(url, headers=user_agent, verify=False)
    reply = response.text

    if reply.__contains__(error1) or reply.__contains__(error2):
        continue

    try:
        result = reply[reply.index(left) + len(left):reply.index(right)]

    except ValueError:
        print("ValueError caught in:", reply, "Continuing..")
        continue

    if int(result) < int(score):
        result = int(result) + 1
        print(entry[:-1], " == ", result)

    if int(result) == 1:
        break
