file = open("../Test/Contexto/Text/wordlistnew.txt", "w")
file_original = open("../Test/Contexto/Text/wordlist.txt", "r")


def contains_number(value):
    for character in value:
        if character.isdigit():
            return 1
    return 2


for entry in file_original:
    if contains_number(entry) == 1:
        continue
    else:
        file.write(entry)
