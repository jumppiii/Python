import os


def cheat_code(x):
    num_range = range(2, x)

    for num in num_range:

        if x % num == 0:
            multi_amount = int(x / num)
            print(num, "*", multi_amount, "\n")


def main():
    os.system("cls")
    daily_number = int(input("Enter the daily number: "))
    print("")
    cheat_code(daily_number)


main()
