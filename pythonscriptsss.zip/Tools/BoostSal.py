import os


def calc(x, y, z):
    print("Salary:", x, "\nYears:", y, "\nPercentage:", round((z-1)*100, 1), "\n")

    inc_money = 0
    num_range = range(0, y)

    for num in num_range:
        new_sal = int(x * z)

        print("This is your salary after", num+1, "years: ", new_sal)
        print("Your increase is", new_sal-x, "\n")
        inc_money += new_sal-x
        x = new_sal

    print("Your total salary increase =", inc_money)


def main():
    os.system("cls")
    salary = int(input("Enter salary: "))
    years = int(input("Enter years to calculate: "))
    percent = float(input("Enter the percentage increase with this format example '4.5' for 4.5% : "))
    percent = percent / 100 + 1
    os.system("cls")
    calc(salary, years, percent)
    input("")


main()
