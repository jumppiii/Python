def test():
    file = open("noop.txt", "r")
    cycle = 0
    V = 0

    for line in file:

        if line[:4] == "noop":
            # print("NootNoot")

            cycle += 1

        elif line[:4] == "addx":
            # print("AddyAddy")

            num = int(line[5:])

            num = num * cycle
            print(num)


test()
