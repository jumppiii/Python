import math

used_letters = []

rucksack = open("rucksack.txt", "r")
result = open("result.txt", "w")

count = 0

for item in rucksack:
    count += 1

    length = len(item)
    length_half = length / 2
    length_half = math.trunc(length_half)

    first_half = item[:length_half]
    second_half = item[length_half:]
    # print(first_half)
    # print(second_half)

    for letter in first_half:
        if second_half.__contains__(letter):
            rucksack = open("rucksack.txt", "r")
            rucksack = rucksack.read()
            print(letter)
            result.write(letter)
            result.write("\n")
            break


result = open("result.txt", "r")
grave = []
for entry in result:
    result = open("result.txt", "r")
    text = result.read()
    amount = text.count(entry)
    if grave.__contains__(entry):
        continue
    else:
        print(entry, amount)

    grave.append(entry)

tall = open("tall.txt", "r")
nah = 0
for t in tall:
    t = int(t)
    nah += t

print(nah)
