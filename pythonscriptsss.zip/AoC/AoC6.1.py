def attempt_uno(x):  # creates function to parse string
    count = 0
    n1 = ""  # variable that will end up being printed

    for let in x:  # for each letter in x

        if n1.__contains__(let):  # if variable already contains the letter, break loop
            break

        else:  # else add letter to variable and increase the counter
            count += 1
            n1 = n1 + let

        if count == 14:  # if counter == 14, print the variable and exit program
            print(n1)
            exit()


string = open("./TextFiles/wtf.txt", "r").read()  # opens document that has the string and reads it
c = 0  # counter to keep track of each iteration

for letter in string:
    string1 = string[c:]  # string1 variable == an edited version of string document based on the iteration counter
    attempt_uno(string1)  # pass variable string1 to attempt_uno function
    c += 1  # increase counter per iteration with 1
    print(c + 14)  # print the iteration counter + the length of the string
