# todoooo: fix this shit

stack_1 = "TRDHQNPB"
stack_2 = "VTJBGW"
stack_3 = "QMVSDHRN"
stack_4 = "CMNZP"
stack_5 = "BZD"
stack_6 = "ZWCV"
stack_7 = "SLQVCNZG"
stack_8 = "VNDMJGL"
stack_9 = "GCZFMPT"

file = open("directions.txt", "r")

for line in file:

    sep = line.split(" ")  # creates a list

    amount = int(sep[1])  # grabs the amount of boxes to be moved
    # print("Amount:", amount)

    move_from = int(sep[3])  # grabs the stack to move boxes away from
    # print("Move from:", move_from)

    move_to = int(sep[5][:1])  # grabs the stack to move boxes to and ignores the n\ char
    # print("Move to:", move_to)

    stack_move_from = "" + str(move_from)

    if stack_move_from == "1":
        if move_to == 2:
            stack_2 = stack_1[0:amount] + stack_2
            stack_1 = stack_1[amount:]

        elif move_to == 3:
            stack_3 = stack_1[0:amount] + stack_3
            stack_1 = stack_1[amount:]

        elif move_to == 4:
            stack_4 = stack_1[0:amount] + stack_4
            stack_1 = stack_1[amount:]

        elif move_to == 5:
            stack_5 = stack_1[0:amount] + stack_5
            stack_1 = stack_1[amount:]

        elif move_to == 6:
            stack_6 = stack_1[0:amount] + stack_6
            stack_1 = stack_1[amount:]

        elif move_to == 7:
            stack_7 = stack_1[0:amount] + stack_7
            stack_1 = stack_1[amount:]

        elif move_to == 8:
            stack_8 = stack_1[0:amount] + stack_8
            stack_1 = stack_1[amount:]

        elif move_to == 9:
            stack_9 = stack_1[0:amount] + stack_9
            stack_1 = stack_1[amount:]

    elif stack_move_from == "2":
        if move_to == 1:
            stack_1 = stack_2[0:amount] + stack_1
            stack_2 = stack_2[amount:]

        elif move_to == 3:
            stack_3 = stack_2[0:amount] + stack_3
            stack_2 = stack_2[amount:]

        elif move_to == 4:
            stack_4 = stack_2[0:amount] + stack_4
            stack_2 = stack_2[amount:]

        elif move_to == 5:
            stack_5 = stack_2[0:amount] + stack_5
            stack_2 = stack_2[amount:]

        elif move_to == 6:
            stack_6 = stack_2[0:amount] + stack_6
            stack_2 = stack_2[amount:]

        elif move_to == 7:
            stack_7 = stack_2[0:amount] + stack_7
            stack_2 = stack_2[amount:]

        elif move_to == 8:
            stack_8 = stack_2[0:amount] + stack_8
            stack_2 = stack_2[amount:]

        elif move_to == 9:
            stack_9 = stack_2[0:amount] + stack_9
            stack_2 = stack_2[amount:]

    elif stack_move_from == "3":
        if move_to == 1:
            stack_1 = stack_3[0:amount] + stack_1
            stack_3 = stack_3[amount:]

        elif move_to == 2:
            stack_2 = stack_3[0:amount] + stack_2
            stack_3 = stack_3[amount:]

        elif move_to == 4:
            stack_4 = stack_3[0:amount] + stack_4
            stack_3 = stack_3[amount:]

        elif move_to == 5:
            stack_5 = stack_3[0:amount] + stack_5
            stack_3 = stack_3[amount:]

        elif move_to == 6:
            stack_6 = stack_3[0:amount] + stack_6
            stack_3 = stack_3[amount:]

        elif move_to == 7:
            stack_7 = stack_3[0:amount] + stack_7
            stack_3 = stack_3[amount:]

        elif move_to == 8:
            stack_8 = stack_3[0:amount] + stack_8
            stack_3 = stack_3[amount:]

        elif move_to == 9:
            stack_9 = stack_3[0:amount] + stack_9
            stack_3 = stack_3[amount:]

    elif stack_move_from == "4":
        if move_to == 1:
            stack_1 = stack_4[0:amount] + stack_1
            stack_4 = stack_4[amount:]

        elif move_to == 2:
            stack_2 = stack_4[0:amount] + stack_2
            stack_4 = stack_4[amount:]

        elif move_to == 3:
            stack_3 = stack_4[0:amount] + stack_3
            stack_4 = stack_4[amount:]

        elif move_to == 5:
            stack_5 = stack_4[0:amount] + stack_5
            stack_4 = stack_4[amount:]

        elif move_to == 6:
            stack_6 = stack_4[0:amount] + stack_6
            stack_4 = stack_4[amount:]

        elif move_to == 7:
            stack_7 = stack_4[0:amount] + stack_7
            stack_4 = stack_4[amount:]

        elif move_to == 8:
            stack_8 = stack_4[0:amount] + stack_8
            stack_4 = stack_4[amount:]

        elif move_to == 9:
            stack_9 = stack_4[0:amount] + stack_9
            stack_4 = stack_4[amount:]

    elif stack_move_from == "5":
        if move_to == 1:
            stack_1 = stack_5[0:amount] + stack_1
            stack_5 = stack_5[amount:]

        elif move_to == 2:
            stack_2 = stack_5[0:amount] + stack_2
            stack_5 = stack_5[amount:]

        elif move_to == 3:
            stack_3 = stack_5[0:amount] + stack_3
            stack_5 = stack_5[amount:]

        elif move_to == 4:
            stack_4 = stack_5[0:amount] + stack_4
            stack_5 = stack_5[amount:]

        elif move_to == 6:
            stack_6 = stack_5[0:amount] + stack_6
            stack_5 = stack_5[amount:]

        elif move_to == 7:
            stack_7 = stack_5[0:amount] + stack_7
            stack_5 = stack_5[amount:]

        elif move_to == 8:
            stack_8 = stack_5[0:amount] + stack_8
            stack_5 = stack_5[amount:]

        elif move_to == 9:
            stack_9 = stack_5[0:amount] + stack_9
            stack_5 = stack_5[amount:]

    elif stack_move_from == "6":
        if move_to == 1:
            stack_1 = stack_6[0:amount] + stack_1
            stack_6 = stack_6[amount:]

        elif move_to == 2:
            stack_2 = stack_6[0:amount] + stack_2
            stack_6 = stack_6[amount:]

        elif move_to == 3:
            stack_3 = stack_6[0:amount] + stack_3
            stack_6 = stack_6[amount:]

        elif move_to == 4:
            stack_4 = stack_6[0:amount] + stack_4
            stack_6 = stack_6[amount:]

        elif move_to == 5:
            stack_5 = stack_6[0:amount] + stack_5
            stack_6 = stack_6[amount:]

        elif move_to == 7:
            stack_7 = stack_6[0:amount] + stack_7
            stack_6 = stack_6[amount:]

        elif move_to == 8:
            stack_8 = stack_6[0:amount] + stack_8
            stack_6 = stack_6[amount:]

        elif move_to == 9:
            stack_9 = stack_6[0:amount] + stack_9
            stack_6 = stack_6[amount:]

    elif stack_move_from == "7":
        if move_to == 1:
            stack_1 = stack_7[0:amount] + stack_1
            stack_7 = stack_7[amount:]

        elif move_to == 2:
            stack_2 = stack_7[0:amount] + stack_2
            stack_7 = stack_7[amount:]

        elif move_to == 3:
            stack_3 = stack_7[0:amount] + stack_3
            stack_7 = stack_7[amount:]

        elif move_to == 4:
            stack_4 = stack_7[0:amount] + stack_4
            stack_7 = stack_7[amount:]

        elif move_to == 5:
            stack_5 = stack_7[0:amount] + stack_5
            stack_7 = stack_7[amount:]

        elif move_to == 6:
            stack_6 = stack_7[0:amount] + stack_6
            stack_7 = stack_7[amount:]

        elif move_to == 8:
            stack_8 = stack_7[0:amount] + stack_8
            stack_7 = stack_7[amount:]

        elif move_to == 9:
            stack_9 = stack_7[0:amount] + stack_9
            stack_7 = stack_7[amount:]

    elif stack_move_from == "8":
        if move_to == 1:
            stack_1 = stack_8[0:amount] + stack_1
            stack_8 = stack_8[amount:]

        elif move_to == 2:
            stack_2 = stack_8[0:amount] + stack_2
            stack_8 = stack_8[amount:]

        elif move_to == 3:
            stack_3 = stack_8[0:amount] + stack_3
            stack_8 = stack_8[amount:]

        elif move_to == 4:
            stack_4 = stack_8[0:amount] + stack_4
            stack_8 = stack_8[amount:]

        elif move_to == 5:
            stack_5 = stack_8[0:amount] + stack_5
            stack_8 = stack_8[amount:]

        elif move_to == 6:
            stack_6 = stack_8[0:amount] + stack_6
            stack_8 = stack_8[amount:]

        elif move_to == 7:
            stack_7 = stack_8[0:amount] + stack_7
            stack_8 = stack_8[amount:]

        elif move_to == 9:
            stack_9 = stack_8[0:amount] + stack_9
            stack_8 = stack_8[amount:]

    elif stack_move_from == "9":
        if move_to == 1:
            stack_1 = stack_9[0:amount] + stack_1
            stack_9 = stack_9[amount:]

        elif move_to == 2:
            stack_2 = stack_9[0:amount] + stack_2
            stack_9 = stack_9[amount:]

        elif move_to == 3:
            stack_3 = stack_9[0:amount] + stack_3
            stack_9 = stack_9[amount:]

        elif move_to == 4:
            stack_4 = stack_9[0:amount] + stack_4
            stack_9 = stack_9[amount:]

        elif move_to == 5:
            stack_5 = stack_9[0:amount] + stack_5
            stack_9 = stack_9[amount:]

        elif move_to == 6:
            stack_6 = stack_9[0:amount] + stack_6
            stack_9 = stack_9[amount:]

        elif move_to == 7:
            stack_7 = stack_9[0:amount] + stack_7
            stack_9 = stack_9[amount:]

        elif move_to == 8:
            stack_8 = stack_9[0:amount] + stack_8
            stack_9 = stack_9[amount:]

print(stack_1)
print(stack_2)
print(stack_3)
print(stack_4)
print(stack_5)
print(stack_6)
print(stack_7)
print(stack_8)
print(stack_9)
