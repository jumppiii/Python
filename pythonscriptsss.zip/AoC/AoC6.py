def attempt_uno(x):
    count = 0
    n1 = ""

    for let in x:

        if n1.__contains__(let):
            count = 0
            break

        else:
            count += 1
            n1 = n1 + let

        if count == 4:
            print(n1)
            exit()


string = open("wtf.txt", "r").read()

c = 0
for letter in string:
    string1 = string[c:]
    attempt_uno(string1)
    c += 1
    print(c + 4)
