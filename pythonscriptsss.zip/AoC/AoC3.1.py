rucksack = open("rucksack.txt", "r")

count = 0

for item in rucksack:
    count += 1

    if count == 1:
        string1 = item
        # print("S1", string1)

    if count == 2:
        string2 = item
        # print("S2", string2)

    if count == 3:
        string3 = item
        # print("S3", string3)

        for letter in string1:

            if letter in string2 and letter in string3:
                print(letter)

            else:
                continue

        count = 0

legend = open("legend.txt", "r")
legend_two = open("legend2.txt", "w")

for line in legend:
    line = str(line.strip())
    legend_two.write(line)

string_one = "rPVMLBdzJGbJpRntJCGzBNjZjtJzVLpgPrRGRmNzdTFWqmsqVdTVrspCgQtzcFjNVJNfQVGvrWZCdVfZSTgHLMqMFjlNRcgcSrjC"

grave = []

for letter_string in string_one:
    amount = string_one.count(letter_string)

    if grave.__contains__(letter_string):
        continue
    else:
        print(letter_string, amount)

    grave.append(letter_string)



