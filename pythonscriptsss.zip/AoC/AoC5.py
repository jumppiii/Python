# stack_1 = ["T", "R", "D", "H", "Q", "N", "P", "B"]
# stack_2 = ["V", "T", "J", "B", "G", "W"]
# stack_3 = ["Q", "M", "V", "S", "D", "H", "R", "N"]
# stack_4 = ["C", "M", "N", "Z", "P"]
# stack_5 = ["B", "Z", "D"]
# stack_6 = ["Z", "W", "C", "V"]
# stack_7 = ["S", "L", "Q", "V", "C", "N", "Z", "G"]
# stack_8 = ["V", "N", "D", "M", "J", "G", "L"]
# stack_9 = ["G", "C", "Z", "F", "M", "P", "T"]


def moving(x, y):
    if x == 1:
        if y == 2:
            stack_2.insert(0, stack_1[0])
            stack_1.remove(stack_1[0])

        elif y == 3:
            stack_3.insert(0, stack_1[0])
            stack_1.remove(stack_1[0])

        elif y == 4:
            stack_4.insert(0, stack_1[0])
            stack_1.remove(stack_1[0])

        elif y == 5:
            stack_5.insert(0, stack_1[0])
            stack_1.remove(stack_1[0])

        elif y == 6:
            stack_6.insert(0, stack_1[0])
            stack_1.remove(stack_1[0])

        elif y == 7:
            stack_7.insert(0, stack_1[0])
            stack_1.remove(stack_1[0])

        elif y == 8:
            stack_8.insert(0, stack_1[0])
            stack_1.remove(stack_1[0])

        elif y == 9:
            stack_9.insert(0, stack_1[0])
            stack_1.remove(stack_1[0])

    if x == 2:
        if y == 1:
            stack_1.insert(0, stack_2[0])
            stack_2.remove(stack_2[0])

        elif y == 3:
            stack_3.insert(0, stack_2[0])
            stack_2.remove(stack_2[0])

        elif y == 4:
            stack_4.insert(0, stack_2[0])
            stack_2.remove(stack_2[0])

        elif y == 5:
            stack_5.insert(0, stack_2[0])
            stack_2.remove(stack_2[0])

        elif y == 6:
            stack_6.insert(0, stack_2[0])
            stack_2.remove(stack_2[0])

        elif y == 7:
            stack_7.insert(0, stack_2[0])
            stack_2.remove(stack_2[0])

        elif y == 8:
            stack_8.insert(0, stack_2[0])
            stack_2.remove(stack_2[0])

        elif y == 9:
            stack_9.insert(0, stack_2[0])
            stack_2.remove(stack_2[0])

    if x == 3:
        if y == 1:
            stack_1.insert(0, stack_3[0])
            stack_3.remove(stack_3[0])

        elif y == 2:
            stack_2.insert(0, stack_3[0])
            stack_3.remove(stack_3[0])

        elif y == 4:
            stack_4.insert(0, stack_3[0])
            stack_3.remove(stack_3[0])

        elif y == 5:
            stack_5.insert(0, stack_3[0])
            stack_3.remove(stack_3[0])

        elif y == 6:
            stack_6.insert(0, stack_3[0])
            stack_3.remove(stack_3[0])

        elif y == 7:
            stack_7.insert(0, stack_3[0])
            stack_3.remove(stack_3[0])

        elif y == 8:
            stack_8.insert(0, stack_3[0])
            stack_3.remove(stack_3[0])

        elif y == 9:
            stack_9.insert(0, stack_3[0])
            stack_3.remove(stack_3[0])

    if x == 4:
        if y == 1:
            stack_1.insert(0, stack_4[0])
            stack_4.remove(stack_4[0])

        elif y == 2:
            stack_2.insert(0, stack_4[0])
            stack_4.remove(stack_4[0])

        elif y == 3:
            stack_3.insert(0, stack_4[0])
            stack_4.remove(stack_4[0])

        elif y == 5:
            stack_5.insert(0, stack_4[0])
            stack_4.remove(stack_4[0])

        elif y == 6:
            stack_6.insert(0, stack_4[0])
            stack_4.remove(stack_4[0])

        elif y == 7:
            stack_7.insert(0, stack_4[0])
            stack_4.remove(stack_4[0])

        elif y == 8:
            stack_8.insert(0, stack_4[0])
            stack_4.remove(stack_4[0])

        elif y == 9:
            stack_9.insert(0, stack_4[0])
            stack_4.remove(stack_4[0])

    if x == 5:
        if y == 1:
            stack_1.insert(0, stack_5[0])
            stack_5.remove(stack_5[0])

        if y == 2:
            stack_2.insert(0, stack_5[0])
            stack_5.remove(stack_5[0])

        if y == 3:
            stack_3.insert(0, stack_5[0])
            stack_5.remove(stack_5[0])

        if y == 4:
            stack_4.insert(0, stack_5[0])
            stack_5.remove(stack_5[0])

        if y == 6:
            stack_6.insert(0, stack_5[0])
            stack_5.remove(stack_5[0])

        if y == 7:
            stack_7.insert(0, stack_5[0])
            stack_5.remove(stack_5[0])

        if y == 8:
            stack_8.insert(0, stack_5[0])
            stack_5.remove(stack_5[0])

        if y == 9:
            stack_9.insert(0, stack_5[0])
            stack_5.remove(stack_5[0])

    if x == 6:
        if y == 1:
            stack_1.insert(0, stack_6[0])
            stack_6.remove(stack_6[0])

        if y == 2:
            stack_2.insert(0, stack_6[0])
            stack_6.remove(stack_6[0])

        if y == 3:
            stack_3.insert(0, stack_6[0])
            stack_6.remove(stack_6[0])

        if y == 4:
            stack_4.insert(0, stack_6[0])
            stack_6.remove(stack_6[0])

        if y == 5:
            stack_5.insert(0, stack_6[0])
            stack_6.remove(stack_6[0])

        if y == 7:
            stack_7.insert(0, stack_6[0])
            stack_6.remove(stack_6[0])

        if y == 8:
            stack_8.insert(0, stack_6[0])
            stack_6.remove(stack_6[0])

        if y == 9:
            stack_9.insert(0, stack_6[0])
            stack_6.remove(stack_6[0])

    if x == 7:
        if y == 1:
            stack_1.insert(0, stack_7[0])
            stack_7.remove(stack_7[0])

        if y == 2:
            stack_2.insert(0, stack_7[0])
            stack_7.remove(stack_7[0])

        if y == 3:
            stack_3.insert(0, stack_7[0])
            stack_7.remove(stack_7[0])

        if y == 4:
            stack_4.insert(0, stack_7[0])
            stack_7.remove(stack_7[0])

        if y == 5:
            stack_5.insert(0, stack_7[0])
            stack_7.remove(stack_7[0])

        if y == 6:
            stack_6.insert(0, stack_7[0])
            stack_7.remove(stack_7[0])

        if y == 8:
            stack_8.insert(0, stack_7[0])
            stack_7.remove(stack_7[0])

        if y == 9:
            stack_9.insert(0, stack_7[0])
            stack_7.remove(stack_7[0])

    if x == 8:
        if y == 1:
            stack_1.insert(0, stack_8[0])
            stack_8.remove(stack_8[0])

        if y == 2:
            stack_2.insert(0, stack_8[0])
            stack_8.remove(stack_8[0])

        if y == 3:
            stack_3.insert(0, stack_8[0])
            stack_8.remove(stack_8[0])

        if y == 4:
            stack_4.insert(0, stack_8[0])
            stack_8.remove(stack_8[0])

        if y == 5:
            stack_5.insert(0, stack_8[0])
            stack_8.remove(stack_8[0])

        if y == 6:
            stack_6.insert(0, stack_8[0])
            stack_8.remove(stack_8[0])

        if y == 7:
            stack_7.insert(0, stack_8[0])
            stack_8.remove(stack_8[0])

        if y == 9:
            stack_9.insert(0, stack_8[0])
            stack_8.remove(stack_8[0])

    if x == 9:
        if y == 1:
            stack_1.insert(0, stack_9[0])
            stack_9.remove(stack_9[0])

        if y == 2:
            stack_2.insert(0, stack_9[0])
            stack_9.remove(stack_9[0])

        if y == 3:
            stack_3.insert(0, stack_9[0])
            stack_9.remove(stack_9[0])

        if y == 4:
            stack_4.insert(0, stack_9[0])
            stack_9.remove(stack_9[0])

        if y == 5:
            stack_5.insert(0, stack_9[0])
            stack_9.remove(stack_9[0])

        if y == 6:
            stack_6.insert(0, stack_9[0])
            stack_9.remove(stack_9[0])

        if y == 7:
            stack_7.insert(0, stack_9[0])
            stack_9.remove(stack_9[0])

        if y == 8:
            stack_8.insert(0, stack_9[0])
            stack_9.remove(stack_9[0])


file = open("directions.txt", "r")

stack_1 = ["T", "R", "D", "H", "Q", "N", "P", "B"]
stack_2 = ["V", "T", "J", "B", "G", "W"]
stack_3 = ["Q", "M", "V", "S", "D", "H", "R", "N"]
stack_4 = ["C", "M", "N", "Z", "P"]
stack_5 = ["B", "Z", "D"]
stack_6 = ["Z", "W", "C", "V"]
stack_7 = ["S", "L", "Q", "V", "C", "N", "Z", "G"]
stack_8 = ["V", "N", "D", "M", "J", "G", "L"]
stack_9 = ["G", "C", "Z", "F", "M", "P", "T"]

for line in file:

    count = 0

    sep = line.split(" ")  # creates a list

    amount = int(sep[1])  # grabs the amount of boxes to be moved

    move_from = int(sep[3])  # grabs the stack to move boxes away from

    move_to = int(sep[5][:1])  # grabs the stack to move boxes to and ignores the n\ char
    # print(amount, move_from, move_to)

    for times in range(amount):
        moving(move_from, move_to)

print(stack_1)
print(stack_2)
print(stack_3)
print(stack_4)
print(stack_5)
print(stack_6)
print(stack_7)
print(stack_8)
print(stack_9)
