import requests
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

file = open("Text/wordlist.txt", "r")
user_agent = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0'}

error1 = str("This word doesn't count, it's too common")
error2 = str("I don't know this word")

for entry in file:
    # print("Attempting word:", entry)
    num = ""

    url = 'https://api.contexto.me/machado/en/game/129/'
    url = url + entry
    url = url[:-1]

    response = requests.get(url, headers=user_agent, verify=False)
    reply = response.text

    if reply.__contains__(error1):
        print(reply, "hahah")

    # extracts if there is digit in reply
    if any(map(str.isdigit, reply)):
        for letter in reply:
            if letter.isdigit():
                num = num + letter

    if any(map(str.isdigit, num)):
        num = int(num)
        if num < 1000:
            print(entry, "is on place:", num)
    # print(response.text)
