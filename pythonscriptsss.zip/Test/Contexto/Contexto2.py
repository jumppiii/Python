import requests
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

file = open("Text/wordlist.txt", "r")
file1 = open("Text/data.txt", "w")
user_agent = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0'}

count = 0

for entry in file:
    count += 1
    url = "https://api.contexto.me/machado/en/game/129/"
    url = url + entry
    url = url[:-1]
    response = requests.get(url, headers=user_agent, verify=False)
    # print("URL is", url, "\n", response.text)
    file1.write(response.text)

    if count % 100 == 0:
        print("You've reached", count)
