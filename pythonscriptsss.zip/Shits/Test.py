def calc(n1, n2, n3, n4, n5, n6):
    num_list = [n1, n2, n3, n4, n5, n6]

    var1 = 0
    var2 = 0
    var3 = 0
    var4 = 0

    final_num = 0
    daily_num = int(input("Enter the daily number: "))

    while final_num != daily_num:
        for nr in num_list:
            var1 += n1 + n2


def main():
    num1 = int(input("First number:"))
    num2 = int(input("Second number:"))
    num3 = int(input("Third number:"))
    num4 = int(input("Fourth number:"))
    num5 = int(input("Fifth number:"))
    num6 = int(input("Sixth number:"))

    print(num1, num2, num3, num4, num5, num6)

    calc(num1, num2, num3, num4, num5, num6)


main()
