count = 0


def test():
    num = 123456
    num_string = str(num)[::-1]

    # print(num_string)

    x = 15
    x_string = str(x)[::-1]
    print(x_string)
    x_reverted = int(x_string)
    print(x_reverted)


    count = 64
    number = 100
    number_reverse = 100

    if count == 64 and number_reverse == number:
        print("cunt")


def fuckit():
    rag = range(10, 100)
    times_to_mult = 64

    for amount in range(rag):
        for times in times_to_mult:
            reverse_amount = amount
            reverse_amount + amount


def try_hard():
    graveyard = []
    x = 1
    y = 2
    u = 3
    x = str(x)
    y = str(y)
    u = str(u)
    graveyard.append(x)
    graveyard.append(y)
    graveyard.append(u)
    print(graveyard)

    num = 1337129540
    num_str = str(num)
    print(num_str[0:4])
    if num_str[0:4] == "1337":
        print("Yes sir")


def great():
    for num in range(1, 2000000):
        # print(num)
        count = 0
        x = num

        for time in range(2000):
            count += 1

            num_re = str(num)[::-1]

            num_re = int(num_re)

            num = num + num_re

            print(num)

            if count == 2000:
                # print("We counted to 2000!")
                # print(num)
                # print("\n\n")
                num_str = str(num)

                if num_str[0:4] == "1337":
                    print("This is the new number")
                    print(num)
                    print("This is the original number")
                    print(x)


def psycho():
    num = 1896397
    count = 0
    x = num
    for time in range(2000):

        count += 1

        num_re = str(num)[::-1]

        num_re = int(num_re)

        num = num + num_re

        num_str = str(num)

        if count == 2000:
            print(num)

            if num_str[0:4] == "1324":
                print(x)
                print(num_str)


item = "testtesttest"
first_six = item[:6]
last_six = item[6:]
print(first_six)
print(last_six)
for x, y in zip(first_six, last_six):
    print(x)
    print(y)
    if x == y:
        print("this is the similar char:", x)
