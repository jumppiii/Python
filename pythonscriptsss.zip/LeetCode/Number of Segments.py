def solution(string):
    lol = string.split(" ")
    lol1 = len(lol)
    return lol1


s = "Hello askhtg to eagt higdf sæigdg af dgjkdlgnsgdf  fsdfd"
print(solution(s))
