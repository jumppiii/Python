
def reverse_string():
    text = "Hello World"
    text = text[::-1]
    print(text)


for numbers in range(100000, 999999):
    count = 0
    graveyard = []

    for times in range(64):
        count += 1
        number = numbers
        # reverses number to a string
        number_reverse = str(number)[::-1]
        # converts reversed number to int
        number_reverse = int(number_reverse)
        # calcs the new number and saves to number
        number = number + number_reverse
        # saves the new reverse string
        number_reverse = str(number)[::-1]
        # converts new reverse string to int
        number_reverse = int(number_reverse)
        new_number = number
        print(number)
        if count == 64:
            if number_reverse == number:
                count = 0
                print("Original Number:")
                print(numbers)
                print("Palindrome:")
                print(number_reverse)
                print("\n")

